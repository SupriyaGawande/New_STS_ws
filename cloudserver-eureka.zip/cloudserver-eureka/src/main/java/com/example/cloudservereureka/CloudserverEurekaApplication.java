package com.example.cloudservereureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudserverEurekaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudserverEurekaApplication.class, args);
	}

}
