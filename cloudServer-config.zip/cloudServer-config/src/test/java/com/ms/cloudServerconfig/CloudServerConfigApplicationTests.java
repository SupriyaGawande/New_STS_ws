package com.ms.cloudServerconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudServerConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
